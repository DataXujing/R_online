OpenCPU App: Stocks
-------------------

NB: this app no longer works because Google silently killed off the Finance API.

Simple OpenCPU Application. To run R:

```r
#load the app
library(opencpu)
ocpu_start_app('rwebapps/stockapp')
```

You can also use the app on https://rwebapps.ocpu.io/stockapp/
