# Simple Jug CRUD example

An Angular based TODO app using the [Jug](https://github.com/Bart6114/jug) backend for data storage/retrieval (non-persistent).

It does not neccesarily show front-/backend development best practices, but serves as an example of how to communicate with the Jug backend.

![screenshot](http://i.imgur.com/k1anAYh.png)

## How to use it

Clone the repository, run ```app.R``` and browse to ```http://127.0.0.1:8080/```.